// Netlify serverless function: bill recognition via Google Gemini (free)
// Keeps the API key safe on the server.

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { image } = JSON.parse(event.body || '{}');
    if (!image) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing image' }) };
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: 'Server missing GEMINI_API_KEY env var' }) };
    }

    const prompt = `You are a money recognition expert helping visually impaired users identify Philippine peso banknotes (New Generation Currency series).

You must identify ONE of these six denominations based on what you see:

20 pesos - ORANGE bill. Front: Manuel L. Quezon + Declaration of Philippine Independence. Back: Banaue Rice Terraces, Asian palm civet.

50 pesos - RED/REDDISH bill. Front: Sergio Osmena + first Philippine National Assembly. Back: Taal Lake, maliputo fish.

100 pesos - VIOLET/PURPLE bill. Front: Manuel A. Roxas + Old Central Bank building. Back: Mayon Volcano, whale shark (butanding).

200 pesos - GREEN bill. Front: Diosdado Macapagal + EDSA People Power II / Aguinaldo Shrine. Back: Bohol Chocolate Hills, Philippine tarsier.

500 pesos - YELLOW/YELLOW-GOLD bill. Front: Corazon and Benigno Aquino Jr. + EDSA People Power. Back: Puerto Princesa Subterranean River, blue-naped parrot.

1000 pesos - BLUE bill. Front: Jose Abad Santos, Vicente Lim, Josefa Llanes Escoda (three WWII heroes) OR Philippine Eagle on newer polymer version. Back: Tubbataha Reefs, South Sea pearl.

IDENTIFICATION STRATEGY:
1. FIRST check the dominant color - fastest and most reliable:
   Orange=20, Red=50, Purple=100, Green=200, Yellow=500, Blue=1000
2. THEN look for the number printed on the bill corners
3. THEN confirm with the person's face or landmark
4. If color is clearly one of the six, be decisive.

Respond with ONLY a JSON object. No markdown, no code fences, no extra text:
{"detected": boolean, "denomination": number or null, "confidence": "high" or "medium" or "low", "notes": "short message"}

Rules:
- denomination must be exactly one of: 20, 50, 100, 200, 500, 1000 (or null)
- If image is too blurry or no bill visible: detected: false
- notes: short helpful message under 15 words
- Be decisive when color is clearly identifiable. Don't refuse if you can see the color.

What Philippine peso bill is this?`;

    // Gemini API endpoint - using gemini-2.0-flash which is free and supports vision
    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

    const geminiRes = await fetch(geminiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [
            { text: prompt },
            { inline_data: { mime_type: 'image/jpeg', data: image } }
          ]
        }],
        generationConfig: {
          temperature: 0.2,
          maxOutputTokens: 300,
          responseMimeType: 'application/json'
        }
      })
    });

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      return { statusCode: geminiRes.status, headers, body: JSON.stringify({ error: 'Gemini API error', detail: errText }) };
    }

    const data = await geminiRes.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const cleaned = text.replace(/```json|```/g, '').trim();

    let parsed;
    try { parsed = JSON.parse(cleaned); }
    catch (e) {
      const m = cleaned.match(/\{[\s\S]*\}/);
      if (m) parsed = JSON.parse(m[0]);
      else return { statusCode: 502, headers, body: JSON.stringify({ error: 'Bad AI response', raw: cleaned }) };
    }

    return { statusCode: 200, headers, body: JSON.stringify(parsed) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
